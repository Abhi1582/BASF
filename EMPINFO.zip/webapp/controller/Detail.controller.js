sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.ns.EMPINFO.controller.Detail", {
		onInit: function () {
			// var oModel2 = new sap.ui.model.odata.ODataModel("https://cors-anywhere.herokuapp.com/http://services.odata.org/V3/northwind/northwind.svc"); //working
			// this.getView().setModel(oModel2);
		}
	});
});