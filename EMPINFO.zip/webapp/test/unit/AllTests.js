sap.ui.define([
	"com/ns/EMPINFO/test/unit/controller/Master.controller"
], function () {
	"use strict";
});